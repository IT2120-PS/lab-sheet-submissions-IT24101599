setwd("C:\\Users\\Samadi\\Desktop\\IT24101599\\Lab_06")
getwd()

#Q1

#part i
#random variable X has binomial distribution with n=50 , p=0.85

#part ii
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)


#Q2

#part i
#Avg calls per hour

#part ii
#random variable X has poisson distribution with lambda=12

#part iii
dpois(15, 12)

