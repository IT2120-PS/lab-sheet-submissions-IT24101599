setwd("C:\\Users\\Samadi\\Desktop\\IT24101599\\Lab_05")
getwd()

#1
Delivery_times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")
fix(Delivery_times)
attach(Delivery_times)

#2
hist(Delivery_Times$Delivery_Time, breaks = seq(20, 70, length.out = 10), right = FALSE, main = "Histogram of Delivery Times", xlab = "Delivery Time (minutes)", ylab = "Frequency")

#3
#The histogram shows most delivery times around 40 minutes.
#The distribution looks like a bell-shaped but with a slight stretch to the right (toward 60–70 minutes).

#4)
hist_obj <- hist(Delivery_Times$Delivery_Time, breaks = seq(20, 70, length.out = 10), right = FALSE, plot = FALSE)
cumfreq <- cumsum(hist_obj$counts)
plot(hist_obj$breaks, c(0, cumfreq), type = "o", main = "Ogive of Delivery Times", xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency", pch = 19)
