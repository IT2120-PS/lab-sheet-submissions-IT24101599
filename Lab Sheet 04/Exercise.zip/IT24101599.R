setwd("C:\\Users\\IT24101599\\Desktop\\IT24101599\\Lab 4")
getwd()

#1
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
fix(branch_data)
attach(branch_data)

#2
boxplot (Sales_X1, main="Sales", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot (Advertising_X2, main="Advertising", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot (Years_X3, main="Years", outline=TRUE, outpch=8, horizontal=TRUE)

#4
summary(Advertising_X2)
